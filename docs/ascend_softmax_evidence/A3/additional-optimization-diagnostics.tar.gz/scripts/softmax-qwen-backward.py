import json,inspect,csv,statistics,collections
from pathlib import Path
import torch,torch_npu,triton
from liger_kernel.ops.backends._ascend.ops import _softmax_optimized as sm
is_a3=torch.npu.get_device_name().startswith(sm.A3_DEVICE_PREFIX)
shape=(2048,3584)
x=torch.randn(*shape,device='npu',dtype=torch.bfloat16,requires_grad=True);dy=torch.randn_like(x)
reference=torch.softmax(x,-1);reference.backward(dy,retain_graph=True);expected=x.grad.clone();x.grad=None
fwd=sm._launcher(*shape,x.dtype,0,False);saved_name=torch.npu.get_device_name
original_launcher=sm._launcher
code=inspect.getsource(sm._launcher.__wrapped__).replace('or cols != col_tile','or False')
exec(code,sm.__dict__)
fused_launcher=sm._launcher
cs=[]
for family in ['split']:
 for tile in [2,4,8]:
  for multi in [False,True]:
   try:
    sm._launcher=original_launcher if family!='fused' else fused_launcher
    sm._launcher.cache_clear();sm.A3_SHORT_ROW_LIMIT=0 if family=='persistent' else 2048
    torch.npu.get_device_name=saved_name if family=='persistent' else (lambda device=None:'Ascend910B3') if family=='split' else (lambda device=None:'generic')
    b=sm._launcher(*shape,x.dtype,0,True,tile,multi)
    context=sm._native_module().CachedOp(lambda _,b=b:(fwd.native_spec,b.native_spec)).context(x)
    y=context.apply(x);x.grad=None;y.backward(dy,retain_graph=True)
    torch.testing.assert_close(x.grad,expected,atol=.02,rtol=.02)
    name=f'{family}_r{tile}_mb{multi}'
    cs.append((name,y));print('CANDIDATE',name,b.native_spec[0].name,flush=True)
   except Exception as e:print('REJECT',family,tile,multi,str(e)[-200:],flush=True)
torch.npu.get_device_name=saved_name;sm._launcher=original_launcher
cs.append(('torch',reference));torch.npu.synchronize()
cache=triton.runtime.driver.active.get_empty_cache_for_benchmark()
root=Path('/workspace/softmax1802/results/profile_a3_qwen_backward');root.mkdir(exist_ok=True)
repeats=10
(root/'mapping.json').write_text(json.dumps({'shape':shape,'candidates':[n for n,y in cs],'repeats':repeats}))
with torch_npu.profiler.profile(activities=[torch_npu.profiler.ProfilerActivity.CPU,torch_npu.profiler.ProfilerActivity.NPU],schedule=torch_npu.profiler.schedule(wait=0,warmup=1,active=len(cs)*repeats,repeat=1),on_trace_ready=torch_npu.profiler.tensorboard_trace_handler(str(root))) as prof:
 for i in range(len(cs)*repeats+1):
  name,y=cs[max(0,(i-1)//repeats)]
  x.grad=None;cache.zero_()
  with torch.autograd.profiler.record_function('candidate:'+name):y.backward(dy,retain_graph=True)
  prof.step()
 torch.npu.synchronize()
results=collections.defaultdict(list)
for p in root.rglob('kernel_details.csv'):
 for r in csv.DictReader(p.open()):
  if 'Zero' in r['Name'] or not r['Step Id'].isdigit():continue
  step=int(r['Step Id']);idx=(step-1)//repeats
  if 0<=idx<len(cs):results[cs[idx][0]].append(float(r['Duration(us)']))
for n,v in results.items():print('RESULT',json.dumps({'name':n,'median_us':statistics.median(v),'min_us':min(v),'max_us':max(v),'samples':len(v)}),flush=True)
