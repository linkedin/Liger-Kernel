import torch,torch_npu,triton
import triton.language as tl
import csv,json,statistics,collections
from pathlib import Path
from liger_kernel.ops.backends._ascend.ops import _softmax_optimized as sm
from liger_kernel.ops.backends._ascend.ops._softmax_launcher import native_entry
@triton.jit(do_not_specialize_on_alignment=[0,1,2])
def persistent_backward(DY,Y,DX,ROWS:tl.constexpr,COLS:tl.constexpr,R:tl.constexpr,C:tl.constexpr,PROGRAMS:tl.constexpr,MODE:tl.constexpr):
 tiles:tl.constexpr=(ROWS+PROGRAMS*R-1)//(PROGRAMS*R)
 if MODE==0:
  start=tl.program_id(0)*R;stop=ROWS;step=tl.num_programs(0)*R
 elif MODE==1:
  start=tl.program_id(0)*R;stop=ROWS;step=PROGRAMS*R
 else:
  start=tl.program_id(0)*tiles*R;stop=start+tiles*R;step=R
 for base in range(start,stop,step):
  rows=base.to(tl.int64)+tl.arange(0,R)
  cols=tl.arange(0,C);idx=rows[:,None]*COLS+cols[None,:]
  mask=(rows[:,None]<ROWS)&(cols[None,:]<COLS)
  dy=tl.load(DY+idx,mask,other=0).to(tl.float32);y=tl.load(Y+idx,mask,other=0).to(tl.float32)
  dot=tl.sum(dy*y,1)
  tl.store(DX+idx,y*(dy-dot[:,None]),mask)
for shape in [(2048,4096)]:
 rows,cols=shape;tile=2 if rows<4096 else 1;mb=rows<4096
 x=torch.randn(*shape,device='npu',dtype=torch.bfloat16,requires_grad=True);dy=torch.randn_like(x)
 ref=torch.softmax(x,-1);ref.backward(dy,retain_graph=True);expected=x.grad.clone();x.grad=None
 fwd=sm._launcher(*shape,x.dtype,0,False);cs=[]
 cores=int(triton.runtime.driver.active.utils.get_device_properties(0)['num_vectorcore'])
 for wide,fma in [(n,m) for n in [cores//2,cores] for m in [0,1,2]]:
  try:
   grid=(wide,1,1)
   compiled=persistent_backward.warmup(x.dtype,x.dtype,x.dtype,rows,cols,tile,cols,wide,fma,grid=grid,multibuffer=mb);compiled._init_handles();library,entry=native_entry(compiled,grid)
   spec=(compiled,grid,sm._native_module().current_stream,0,library,entry)
   ctx=sm._native_module().CachedOp(lambda _,b=spec:(fwd.native_spec,b)).context(x);out=ctx.apply(x);x.grad=None;out.backward(dy,retain_graph=True)
   torch.testing.assert_close(x.grad,expected,atol=.02,rtol=.02)
   name=f'programs{wide}_mode{fma}';cs.append((name,out));print('CANDIDATE',shape,name,flush=True)
  except Exception as e:print('REJECT',shape,wide,fma,str(e)[-180:],flush=True)
 cs.append(('torch',ref));torch.npu.synchronize()
 cache=triton.runtime.driver.active.get_empty_cache_for_benchmark();root=Path('/workspace/softmax1802/results/profile_backward_partition_'+str(rows));root.mkdir(exist_ok=True);repeats=15
 (root/'mapping.json').write_text(json.dumps({'shape':shape,'names':[n for n,f in cs],'repeats':repeats}))
 with torch_npu.profiler.profile(activities=[torch_npu.profiler.ProfilerActivity.CPU,torch_npu.profiler.ProfilerActivity.NPU],schedule=torch_npu.profiler.schedule(wait=0,warmup=1,active=len(cs)*repeats,repeat=1),on_trace_ready=torch_npu.profiler.tensorboard_trace_handler(str(root))) as prof:
  for i in range(len(cs)*repeats+1):
   name,y=cs[max(0,(i-1)//repeats)];x.grad=None;cache.zero_()
   with torch.autograd.profiler.record_function('candidate:'+name):y.backward(dy,retain_graph=True)
   prof.step()
  torch.npu.synchronize()
 results=collections.defaultdict(list)
 for p in root.rglob('kernel_details.csv'):
  for r in csv.DictReader(p.open()):
   if 'Zero' in r['Name'] or not r['Step Id'].isdigit():continue
   idx=(int(r['Step Id'])-1)//repeats
   if 0<=idx<len(cs):results[cs[idx][0]].append(float(r['Duration(us)']))
 for n,v in results.items():print('RESULT',json.dumps({'shape':shape,'name':n,'median_us':statistics.median(v),'samples':len(v)}),flush=True)
