import torch,torch_npu,triton
import triton.language as tl
import csv,json,statistics,collections
from pathlib import Path
from liger_kernel.ops.backends._ascend.ops import _softmax_optimized as sm
from liger_kernel.ops.backends._ascend.ops._softmax_launcher import native_entry
@triton.jit(do_not_specialize_on_alignment=[0,1,2])
def segmented2(DY,Y,DX,ROWS:tl.constexpr,COLS:tl.constexpr,R:tl.constexpr,C:tl.constexpr,K:tl.constexpr,UNUSED:tl.constexpr):
 rows=tl.program_id(0).to(tl.int64)*R+tl.arange(0,R)
 c0=tl.arange(0,C//2)+0*(C//2)
 i0=rows[:,None]*COLS+c0[None,:]
 m0=(rows[:,None]<ROWS)&(c0[None,:]<COLS)
 y0=tl.load(Y+i0,m0,other=0).to(tl.float32)
 d0=tl.load(DY+i0,m0,other=0).to(tl.float32)
 c1=tl.arange(0,C//2)+1*(C//2)
 i1=rows[:,None]*COLS+c1[None,:]
 m1=(rows[:,None]<ROWS)&(c1[None,:]<COLS)
 y1=tl.load(Y+i1,m1,other=0).to(tl.float32)
 d1=tl.load(DY+i1,m1,other=0).to(tl.float32)
 dot=tl.sum(y0*d0,1)+tl.sum(y1*d1,1)
 tl.store(DX+i0,y0*(d0-dot[:,None]),m0)
 tl.store(DX+i1,y1*(d1-dot[:,None]),m1)
@triton.jit(do_not_specialize_on_alignment=[0,1,2])
def segmented4(DY,Y,DX,ROWS:tl.constexpr,COLS:tl.constexpr,R:tl.constexpr,C:tl.constexpr,K:tl.constexpr,UNUSED:tl.constexpr):
 rows=tl.program_id(0).to(tl.int64)*R+tl.arange(0,R)
 c0=tl.arange(0,C//4)+0*(C//4)
 i0=rows[:,None]*COLS+c0[None,:]
 m0=(rows[:,None]<ROWS)&(c0[None,:]<COLS)
 y0=tl.load(Y+i0,m0,other=0).to(tl.float32)
 d0=tl.load(DY+i0,m0,other=0).to(tl.float32)
 c1=tl.arange(0,C//4)+1*(C//4)
 i1=rows[:,None]*COLS+c1[None,:]
 m1=(rows[:,None]<ROWS)&(c1[None,:]<COLS)
 y1=tl.load(Y+i1,m1,other=0).to(tl.float32)
 d1=tl.load(DY+i1,m1,other=0).to(tl.float32)
 c2=tl.arange(0,C//4)+2*(C//4)
 i2=rows[:,None]*COLS+c2[None,:]
 m2=(rows[:,None]<ROWS)&(c2[None,:]<COLS)
 y2=tl.load(Y+i2,m2,other=0).to(tl.float32)
 d2=tl.load(DY+i2,m2,other=0).to(tl.float32)
 c3=tl.arange(0,C//4)+3*(C//4)
 i3=rows[:,None]*COLS+c3[None,:]
 m3=(rows[:,None]<ROWS)&(c3[None,:]<COLS)
 y3=tl.load(Y+i3,m3,other=0).to(tl.float32)
 d3=tl.load(DY+i3,m3,other=0).to(tl.float32)
 dot=tl.sum(y0*d0,1)+tl.sum(y1*d1,1)+tl.sum(y2*d2,1)+tl.sum(y3*d3,1)
 tl.store(DX+i0,y0*(d0-dot[:,None]),m0)
 tl.store(DX+i1,y1*(d1-dot[:,None]),m1)
 tl.store(DX+i2,y2*(d2-dot[:,None]),m2)
 tl.store(DX+i3,y3*(d3-dot[:,None]),m3)
@triton.jit(do_not_specialize_on_alignment=[0,1,2])
def segmented8(DY,Y,DX,ROWS:tl.constexpr,COLS:tl.constexpr,R:tl.constexpr,C:tl.constexpr,K:tl.constexpr,UNUSED:tl.constexpr):
 rows=tl.program_id(0).to(tl.int64)*R+tl.arange(0,R)
 c0=tl.arange(0,C//8)+0*(C//8)
 i0=rows[:,None]*COLS+c0[None,:]
 m0=(rows[:,None]<ROWS)&(c0[None,:]<COLS)
 y0=tl.load(Y+i0,m0,other=0).to(tl.float32)
 d0=tl.load(DY+i0,m0,other=0).to(tl.float32)
 c1=tl.arange(0,C//8)+1*(C//8)
 i1=rows[:,None]*COLS+c1[None,:]
 m1=(rows[:,None]<ROWS)&(c1[None,:]<COLS)
 y1=tl.load(Y+i1,m1,other=0).to(tl.float32)
 d1=tl.load(DY+i1,m1,other=0).to(tl.float32)
 c2=tl.arange(0,C//8)+2*(C//8)
 i2=rows[:,None]*COLS+c2[None,:]
 m2=(rows[:,None]<ROWS)&(c2[None,:]<COLS)
 y2=tl.load(Y+i2,m2,other=0).to(tl.float32)
 d2=tl.load(DY+i2,m2,other=0).to(tl.float32)
 c3=tl.arange(0,C//8)+3*(C//8)
 i3=rows[:,None]*COLS+c3[None,:]
 m3=(rows[:,None]<ROWS)&(c3[None,:]<COLS)
 y3=tl.load(Y+i3,m3,other=0).to(tl.float32)
 d3=tl.load(DY+i3,m3,other=0).to(tl.float32)
 c4=tl.arange(0,C//8)+4*(C//8)
 i4=rows[:,None]*COLS+c4[None,:]
 m4=(rows[:,None]<ROWS)&(c4[None,:]<COLS)
 y4=tl.load(Y+i4,m4,other=0).to(tl.float32)
 d4=tl.load(DY+i4,m4,other=0).to(tl.float32)
 c5=tl.arange(0,C//8)+5*(C//8)
 i5=rows[:,None]*COLS+c5[None,:]
 m5=(rows[:,None]<ROWS)&(c5[None,:]<COLS)
 y5=tl.load(Y+i5,m5,other=0).to(tl.float32)
 d5=tl.load(DY+i5,m5,other=0).to(tl.float32)
 c6=tl.arange(0,C//8)+6*(C//8)
 i6=rows[:,None]*COLS+c6[None,:]
 m6=(rows[:,None]<ROWS)&(c6[None,:]<COLS)
 y6=tl.load(Y+i6,m6,other=0).to(tl.float32)
 d6=tl.load(DY+i6,m6,other=0).to(tl.float32)
 c7=tl.arange(0,C//8)+7*(C//8)
 i7=rows[:,None]*COLS+c7[None,:]
 m7=(rows[:,None]<ROWS)&(c7[None,:]<COLS)
 y7=tl.load(Y+i7,m7,other=0).to(tl.float32)
 d7=tl.load(DY+i7,m7,other=0).to(tl.float32)
 dot=tl.sum(y0*d0,1)+tl.sum(y1*d1,1)+tl.sum(y2*d2,1)+tl.sum(y3*d3,1)+tl.sum(y4*d4,1)+tl.sum(y5*d5,1)+tl.sum(y6*d6,1)+tl.sum(y7*d7,1)
 tl.store(DX+i0,y0*(d0-dot[:,None]),m0)
 tl.store(DX+i1,y1*(d1-dot[:,None]),m1)
 tl.store(DX+i2,y2*(d2-dot[:,None]),m2)
 tl.store(DX+i3,y3*(d3-dot[:,None]),m3)
 tl.store(DX+i4,y4*(d4-dot[:,None]),m4)
 tl.store(DX+i5,y5*(d5-dot[:,None]),m5)
 tl.store(DX+i6,y6*(d6-dot[:,None]),m6)
 tl.store(DX+i7,y7*(d7-dot[:,None]),m7)
for shape in [(2048,4096),(2048,3584)]:
 rows,cols=shape;tile=2 if rows<4096 else 1;mb=rows<4096
 x=torch.randn(*shape,device='npu',dtype=torch.bfloat16,requires_grad=True);dy=torch.randn_like(x)
 ref=torch.softmax(x,-1);ref.backward(dy,retain_graph=True);expected=x.grad.clone();x.grad=None
 fwd=sm._launcher(*shape,x.dtype,0,False);cs=[]
 cores=int(triton.runtime.driver.active.utils.get_device_properties(0)['num_vectorcore'])
 for wide,fma in [(r,(p,m)) for r in [2,4,8] for p in [2,4,8] for m in [True,False]]:
  try:
   tile=wide;parts,mb=fma;grid=(triton.cdiv(rows,tile),1,1)
   kernel=globals()[f'segmented{parts}']
   compiled=kernel.warmup(x.dtype,x.dtype,x.dtype,rows,cols,tile,triton.next_power_of_2(cols),wide,False,grid=grid,multibuffer=mb);compiled._init_handles();library,entry=native_entry(compiled,grid)
   spec=(compiled,grid,sm._native_module().current_stream,0,library,entry)
   ctx=sm._native_module().CachedOp(lambda _,b=spec:(fwd.native_spec,b)).context(x);out=ctx.apply(x);x.grad=None;out.backward(dy,retain_graph=True)
   torch.testing.assert_close(x.grad,expected,atol=.02,rtol=.02)
   name=f'groups{wide}_{fma}';cs.append((name,out));print('CANDIDATE',shape,name,flush=True)
  except Exception as e:print('REJECT',shape,wide,fma,str(e)[-180:],flush=True)
 ctx=sm._native_module().CachedOp(sm._native_specs).context(x);cs.append(('current',ctx.apply(x)));cs.append(('torch',ref));torch.npu.synchronize()
 cache=triton.runtime.driver.active.get_empty_cache_for_benchmark();root=Path('/workspace/softmax1802/results/profile_backward_segments_'+str(cols));root.mkdir(exist_ok=True);repeats=15
 (root/'mapping.json').write_text(json.dumps({'shape':shape,'names':[n for n,f in cs],'repeats':repeats}))
 with torch_npu.profiler.profile(activities=[torch_npu.profiler.ProfilerActivity.CPU,torch_npu.profiler.ProfilerActivity.NPU],schedule=torch_npu.profiler.schedule(wait=0,warmup=1,active=len(cs)*repeats,repeat=1),on_trace_ready=torch_npu.profiler.tensorboard_trace_handler(str(root))) as prof:
  for i in range(len(cs)*repeats+1):
   name,y=cs[max(0,(i-1)//repeats)];x.grad=None;cache.zero_()
   with torch.autograd.profiler.record_function('candidate:'+name):y.backward(dy,retain_graph=True)
   prof.step()
  torch.npu.synchronize()
 results=collections.defaultdict(list)
 for p in root.rglob('kernel_details.csv'):
  for r in csv.DictReader(p.open()):
   if 'Zero' in r['Name'] or not r['Step Id'].isdigit():continue
   idx=(int(r['Step Id'])-1)//repeats
   if 0<=idx<len(cs):results[cs[idx][0]].append(float(r['Duration(us)']))
 for n,v in results.items():print('RESULT',json.dumps({'shape':shape,'name':n,'median_us':statistics.median(v),'samples':len(v)}),flush=True)
