import torch,torch_npu,triton
import csv,json,statistics,collections
from pathlib import Path
from liger_kernel.ops.backends._ascend.ops import _softmax_optimized as sm
shape=(2048,4096);n=shape[0]*shape[1]
x=torch.randn(shape,device='npu',dtype=torch.bfloat16,requires_grad=True);ref=torch.softmax(x,-1);dy=torch.randn_like(ref);ref.backward(dy);expected=x.grad.clone()
launch=sm._launcher(*shape,x.dtype,0,True);cs=[];mapping=[]
for yo,do in [(0,0),(0,128),(0,256),(0,512),(128,0),(256,0),(512,0),(128,256),(256,512),(512,1024)]:
 y=torch.empty(n+yo,device='npu',dtype=x.dtype)[yo:].reshape(shape);y.copy_(ref)
 dx=torch.empty(n+do,device='npu',dtype=x.dtype)[do:].reshape(shape)
 launch(dy,y,dx);torch.testing.assert_close(dx,expected,atol=.02,rtol=.02)
 name=f'y{yo}_dx{do}';cs.append((name,lambda y=y,dx=dx:launch(dy,y,dx)))
 mapping.append({'name':name,'dy_address':dy.data_ptr(),'y_address':y.data_ptr(),'dx_address':dx.data_ptr()})
cs.append(('torch',lambda:torch.ops.aten._softmax_backward_data(dy,ref,-1,x.dtype)));torch.npu.synchronize()
cache=triton.runtime.driver.active.get_empty_cache_for_benchmark();root=Path('/workspace/softmax1802/results/profile_address_probe');root.mkdir(exist_ok=True);repeats=15
(root/'mapping.json').write_text(json.dumps({'shape':shape,'names':[n for n,f in cs],'repeats':repeats,'addresses':mapping}))
with torch_npu.profiler.profile(activities=[torch_npu.profiler.ProfilerActivity.CPU,torch_npu.profiler.ProfilerActivity.NPU],schedule=torch_npu.profiler.schedule(wait=0,warmup=1,active=len(cs)*repeats,repeat=1),on_trace_ready=torch_npu.profiler.tensorboard_trace_handler(str(root))) as prof:
 for i in range(len(cs)*repeats+1):
  name,fn=cs[max(0,(i-1)//repeats)];cache.zero_()
  with torch.autograd.profiler.record_function('candidate:'+name):fn()
  prof.step()
 torch.npu.synchronize()
results=collections.defaultdict(list)
for p in root.rglob('kernel_details.csv'):
 for r in csv.DictReader(p.open()):
  if 'Zero' in r['Name'] or not r['Step Id'].isdigit():continue
  idx=(int(r['Step Id'])-1)//repeats
  if 0<=idx<len(cs):results[cs[idx][0]].append(float(r['Duration(us)']))
for n,v in results.items():print('RESULT',json.dumps({'name':n,'median_us':statistics.median(v),'samples':len(v)}),flush=True)
