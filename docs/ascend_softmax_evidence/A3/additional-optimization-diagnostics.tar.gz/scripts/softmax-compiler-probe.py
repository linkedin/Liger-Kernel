import torch,torch_npu,triton
import csv,json,statistics,collections,sys
from pathlib import Path
from liger_kernel.ops.backends._ascend.ops import _softmax_optimized as sm
from liger_kernel.ops.backends._ascend.ops._softmax_launcher import native_entry
backward=sys.argv[1]=='backward'
options=[('default',{}),('buffer_reuse_off',{'disable_tightly_coupled_buffer_reuse':True}),('ub_refine',{'enable_ub_refine_opt':True}),('buffer_insert',{'enable_buffer_insert_optimization':True}),('multi_consumer',{'hfusion_enable_multiple_consumer_fusion':True}),('vf_substitution',{'enable_vf_operand_substitution':True}),('block2',{'auto_blockify_size':2}),('stages3',{'num_stages':3}),('dynamic_offset',{'optimize_dynamic_offset':True})]
for shape in ([(2048,4096),(2048,3584)] if backward else [(1024,4096)]):
 rows,cols=shape;x=torch.randn(*shape,device='npu',dtype=torch.bfloat16,requires_grad=True);dy=torch.randn_like(x);ref=torch.softmax(x,-1);ref.backward(dy,retain_graph=True);expected=x.grad.clone();x.grad=None
 base=sm._launcher(*shape,x.dtype,0,backward);other=sm._launcher(*shape,x.dtype,0,not backward);old,grid,*_=base.native_spec
 cs=[]
 for name,kw in options:
  try:
   compiled=old.src.fn.warmup(*([x.dtype]*(3 if backward else 2)),**old.src.constants,grid=grid,multibuffer=base.multibuffer,**kw)
   compiled._init_handles();library,entry=native_entry(compiled,grid)
   spec=(compiled,grid,sm._native_module().current_stream,0,library,entry)
   ctx=sm._native_module().CachedOp(lambda _,s=spec: (other.native_spec,s) if backward else (s,other.native_spec)).context(x)
   out=ctx.apply(x);torch.testing.assert_close(out,ref,atol=.02,rtol=.02)
   if backward:
    x.grad=None;out.backward(dy,retain_graph=True);torch.testing.assert_close(x.grad,expected,atol=.02,rtol=.02)
   cs.append((name,out if backward else lambda ctx=ctx:ctx.apply(x)));print('CANDIDATE',shape,name,flush=True)
  except Exception as e:print('REJECT',shape,name,str(e)[-300:],flush=True)
 cs.append(('torch',ref if backward else lambda:torch.softmax(x,-1)));torch.npu.synchronize()
 cache=triton.runtime.driver.active.get_empty_cache_for_benchmark();root=Path(f'/workspace/softmax1802/results/profile_compiler_{sys.argv[1]}_{rows}_{cols}');root.mkdir(exist_ok=True);repeats=15
 (root/'mapping.json').write_text(json.dumps({'shape':shape,'names':[n for n,f in cs],'repeats':repeats}))
 with torch_npu.profiler.profile(activities=[torch_npu.profiler.ProfilerActivity.CPU,torch_npu.profiler.ProfilerActivity.NPU],schedule=torch_npu.profiler.schedule(wait=0,warmup=1,active=len(cs)*repeats,repeat=1),on_trace_ready=torch_npu.profiler.tensorboard_trace_handler(str(root))) as prof:
  for i in range(len(cs)*repeats+1):
   name,fn=cs[max(0,(i-1)//repeats)];x.grad=None;cache.zero_()
   with torch.autograd.profiler.record_function('candidate:'+name):
    if backward:fn.backward(dy,retain_graph=True)
    else:fn()
   prof.step()
  torch.npu.synchronize()
 results=collections.defaultdict(list)
 for p in root.rglob('kernel_details.csv'):
  for r in csv.DictReader(p.open()):
   if 'Zero' in r['Name'] or not r['Step Id'].isdigit():continue
   idx=(int(r['Step Id'])-1)//repeats
   if 0<=idx<len(cs):results[cs[idx][0]].append(float(r['Duration(us)']))
 for n,v in results.items():print('RESULT',json.dumps({'shape':shape,'name':n,'median_us':statistics.median(v),'samples':len(v)}),flush=True)
