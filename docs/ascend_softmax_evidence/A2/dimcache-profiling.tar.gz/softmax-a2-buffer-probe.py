import json,os,statistics,time
from pathlib import Path
import torch,torch_npu,triton
from torch.utils.cpp_extension import load
from torch_npu.utils.cpp_extension import NpuExtension
from liger_kernel.ops.backends._ascend.ops import _softmax_optimized as sm
r=Path(sm.__file__).parent;source=r/'_softmax_native.cpp';pkg=Path(torch_npu.__file__).parent
includes=NpuExtension('probe',sources=[str(source)]).include_dirs+[str(Path(os.environ['ASCEND_HOME_PATH'])/'include')]
base=sm._native_module()
for shape in [(1024,4096),(2048,4096)]:
 x=torch.randn(*shape,device='npu',dtype=torch.bfloat16,requires_grad=True);dy=torch.randn_like(x);ref=torch.softmax(x,-1)
 cases=[]
 for name,mb in [('multibuffer',True),('singlebuffer',False)]:
  f=sm._launcher(*shape,x.dtype,0,False,4,mb);b=sm._launcher(*shape,x.dtype,0,True)
  ctx=base.CachedOp(lambda _,f=f,b=b:(f.native_spec,b.native_spec)).context(x)
  out=ctx.apply(x);torch.testing.assert_close(out,ref,atol=.02,rtol=.02)
  cases.append((name,ctx,out))
 torch.npu.synchronize()
 for rnd in range(3):
  for name,ctx,out in (cases if rnd%2==0 else reversed(cases)):
   fwd=triton.testing.do_bench(lambda:ctx.apply(x),quantiles=[.5,.2,.8])
   bwd=None
   print(json.dumps({'shape':shape,'round':rnd,'name':name,'forward_ms':fwd,'backward_ms':bwd}),flush=True)
