import json,os,statistics,time
from pathlib import Path
import torch,torch_npu,triton
from torch.utils.cpp_extension import load
from torch_npu.utils.cpp_extension import NpuExtension
from liger_kernel.ops.backends._ascend.ops import _softmax_optimized as sm
r=Path(sm.__file__).parent;source=r/'_softmax_native.cpp';pkg=Path(torch_npu.__file__).parent
includes=NpuExtension('probe',sources=[str(source)]).include_dirs+[str(Path(os.environ['ASCEND_HOME_PATH'])/'include')]
base=sm._native_module();variant=load(name='softmax_dimcache_release_probe',sources=[str(source)],extra_cflags=['-O3','-DNDEBUG','-fvisibility=hidden'],extra_include_paths=includes,extra_ldflags=[f'-L{pkg / "lib"}','-ltorch_npu'],verbose=False)
for shape in [(1024,4096),(2048,4096)]:
 x=torch.randn(*shape,device='npu',dtype=torch.bfloat16,requires_grad=True);dy=torch.randn_like(x);ref=torch.softmax(x,-1)
 cases=[]
 for name,module in [('default',base),('release',variant)]:
  ctx=module.CachedOp(sm._native_specs).context(x)
  out=ctx.apply(x);torch.testing.assert_close(out,ref,atol=.02,rtol=.02)
  cases.append((name,ctx,out))
 torch.npu.synchronize()
 for rnd in range(3):
  for name,ctx,out in (cases if rnd%2==0 else reversed(cases)):
   fwd=triton.testing.do_bench(lambda:ctx.apply(x),quantiles=[.5,.2,.8])
   bwd=triton.testing.do_bench(lambda:out.backward(dy,retain_graph=True),grad_to_none=[x],quantiles=[.5,.2,.8])
   print(json.dumps({'shape':shape,'round':rnd,'name':name,'forward_ms':fwd,'backward_ms':bwd}),flush=True)
