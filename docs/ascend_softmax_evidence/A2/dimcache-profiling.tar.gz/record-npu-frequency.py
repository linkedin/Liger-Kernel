import ctypes,json,time,sys,pathlib
lib=ctypes.CDLL('/usr/local/Ascend/driver/lib64/driver/libdcmi.so')
lib.dcmi_init.argtypes=[];lib.dcmi_init.restype=ctypes.c_int
init=lib.dcmi_init()
f=lib.dcmi_get_device_frequency;f.argtypes=[ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.POINTER(ctypes.c_uint)];f.restype=ctypes.c_int
pid=int(sys.argv[1]);samples=[]
while pathlib.Path(f'/proc/{pid}').exists():
 vals={}
 for key,kind in [('core_mhz',7),('hbm_mhz',6)]:
  value=ctypes.c_uint();rc=f(5,0,kind,ctypes.byref(value));vals[key]={'rc':rc,'value':value.value}
 samples.append({'unix_time':time.time(),**vals});time.sleep(.5)
print(json.dumps({'init_rc':init,'card':5,'device':0,'samples':samples}))
