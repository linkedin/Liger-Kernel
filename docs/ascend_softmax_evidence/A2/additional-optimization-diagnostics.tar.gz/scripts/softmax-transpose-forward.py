import torch,torch_npu,triton
import triton.language as tl
import csv,json,statistics,collections
from pathlib import Path
from liger_kernel.ops.backends._ascend.ops import _softmax_optimized as sm
from liger_kernel.ops.backends._ascend.ops._softmax_launcher import native_entry
@triton.jit(do_not_specialize_on_alignment=[0,1])
def layout_forward(X,Y,ROWS:tl.constexpr,COLS:tl.constexpr,R:tl.constexpr,C:tl.constexpr,K:tl.constexpr,LOWMAX:tl.constexpr):
 row=tl.program_id(0)*R+tl.arange(0,R)
 col=tl.arange(0,C)
 if K==0:
  idx=row[None,:]*COLS+col[:,None]
  mask=(row[None,:]<ROWS)&(col[:,None]<COLS)
  raw=tl.load(X+idx,mask,other=-float('inf'))
  m=tl.max(raw,0).to(tl.float32)
  e=tl.exp(raw.to(tl.float32)-m[None,:])
  total=tl.sum(e,0)
  tl.store(Y+idx,e*(1.0/total)[None,:],mask)
 else:
  idx=row[:,None]*COLS+col[None,:]
  mask=(row[:,None]<ROWS)&(col[None,:]<COLS)
  raw=tl.load(X+idx,mask,other=-float('inf'))
  m=tl.max(raw,1).to(tl.float32)
  e=tl.exp(raw.to(tl.float32)-m[:,None])
  total=tl.sum(e,1)
  tl.store(Y+idx,e*(1.0/total)[:,None],mask)
for shape in [(1024,4096)]:
 rows,cols=shape;ct=triton.next_power_of_2(cols)
 x=torch.randn(*shape,device='npu',dtype=torch.bfloat16,requires_grad=True);ref=torch.softmax(x,-1)
 bwd=sm._launcher(*shape,x.dtype,0,True);cs=[]
 opts=[('default',{}),('block4',{'auto_blockify_size':4}),('block8',{'auto_blockify_size':8}),('block16',{'auto_blockify_size':16})]
 for tile,k,lm in [(r,k,True) for r in [1,2,4,8,16] for k in [0,1]]:
  for option,kw in [('multibuffer',{'multibuffer':True}),('singlebuffer',{'multibuffer':False})]:
   try:
    grid=(triton.cdiv(rows,tile),1,1)
    compiled=layout_forward.warmup(x.dtype,x.dtype,rows,cols,tile,ct,k,lm,grid=grid,**kw);compiled._init_handles();library,entry=native_entry(compiled,grid)
    spec=(compiled,grid,sm._native_module().current_stream,0,library,entry)
    ctx=sm._native_module().CachedOp(lambda _,f=spec:(f,bwd.native_spec)).context(x)
    torch.testing.assert_close(ctx.apply(x),ref,atol=.005,rtol=.01)
    name=f'r{tile}_k{k}_lowmax{lm}_{option}';cs.append((name,lambda ctx=ctx:ctx.apply(x)));print('CANDIDATE',shape,name,flush=True)
   except Exception as e:print('REJECT',shape,tile,k,lm,option,str(e)[-180:],flush=True)
 ctx=sm._native_module().CachedOp(sm._native_specs).context(x)
 cs.extend([('current',lambda:ctx.apply(x)),('torch',lambda:torch.softmax(x,-1))]);torch.npu.synchronize()
 cache=triton.runtime.driver.active.get_empty_cache_for_benchmark();root=Path('/workspace/softmax1802/results/profile_forward_transpose_'+str(cols));root.mkdir(exist_ok=True);repeats=15
 (root/'mapping.json').write_text(json.dumps({'shape':shape,'names':[n for n,f in cs],'repeats':repeats}))
 with torch_npu.profiler.profile(activities=[torch_npu.profiler.ProfilerActivity.CPU,torch_npu.profiler.ProfilerActivity.NPU],schedule=torch_npu.profiler.schedule(wait=0,warmup=1,active=len(cs)*repeats,repeat=1),on_trace_ready=torch_npu.profiler.tensorboard_trace_handler(str(root))) as prof:
  for i in range(len(cs)*repeats+1):
   name,fn=cs[max(0,(i-1)//repeats)];cache.zero_()
   with torch.autograd.profiler.record_function('candidate:'+name):fn()
   prof.step()
  torch.npu.synchronize()
 results=collections.defaultdict(list)
 for p in root.rglob('kernel_details.csv'):
  for r in csv.DictReader(p.open()):
   if 'Zero' in r['Name'] or not r['Step Id'].isdigit():continue
   idx=(int(r['Step Id'])-1)//repeats
   if 0<=idx<len(cs):results[cs[idx][0]].append(float(r['Duration(us)']))
 for n,v in results.items():print('RESULT',json.dumps({'shape':shape,'name':n,'median_us':statistics.median(v),'samples':len(v)}),flush=True)
